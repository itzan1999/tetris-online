/** @format */

// Archivo con mensajes que se muestran mediante JS

export const ERROR_USER_NOT_AVAILABLE = "Usuario no disponible";
export const ERROR_INVALID_EMAIL = "El email no es valido";
export const ERROR_EMAIL_NOT_AVAILABLE = "Email no disponible";
export const ERROR_PASS_AND_CONFIR_NOT_MATCH = "La contraseña y la confirmacion no coinciden";
